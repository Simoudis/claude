# voice: Jerry Rose

For `@jerryroseevents` and `@jerryrosehomeandgarden`. Every `ig-*` skill uses
this file instead of `voice.md` when the request names either account or
Jerry Rose. Built on 2026-10-19 from the `jerry-rose-brand` skill (baseline
September 7, 2026). That skill is the authority; if the two disagree, it wins,
and this file should be corrected. TODO items are unknown and must not be
guessed.

## How this file overrides the pack

The pack is built for growth accounts. Jerry Rose is a design house whose
copy communicates how the studio sees, designs and cares, not what it sells.

- **Line one is a concrete design detail tied to a principle,** not a hook
  formula. "The vessel sets the proportion." Never "stop scrolling", "nobody
  tells you", "here's why", or a question asked for engagement.
- **25 to 70 words** by default. `caption.py` length checks still apply; a
  short caption is the house style, not a fault.
- **No hashtags, emoji, sales language or tagline by default.** Skip the
  `/ig-hashtag` step unless the user asks for tags, and say so in the receipt.
- **No keyword CTA, no DM funnel, no invented scarcity.** When an ask helps,
  tie it to the actual service and season ("Fall container plantings are
  booking now" only if true and approved). Often there is no ask. A
  `caption.py` warning about a missing ask is intended.
- **Write as "we".** "I" only when the user explicitly asks for Jerry's or
  John's individual voice.
- **The account is named with each photo.** The user says
  `@jerryroseevents` or `@jerryrosehomeandgarden` per post. If a request does
  not say which, ask; never guess from the image.
- **Authorship:** a photo assigned to either account shows Jerry Rose Inc.
  work, so "we designed / we planted / we composed" is accurate. Client
  names, addresses and venues still need authorization.
- **Photo credit:** every caption ends with its own last line,
  `Photos: @simoudis`. All photographs are by John Simoudis.
- **Never describe an image that has not been inspected.** No species,
  venue, date, client or authorship inferred from filenames, mood boards or
  renderings. Image pairings are suggestions until someone looks.
- **Humanize with the brand lexicon.** The stock `slop.json` rewrites
  "curated" to "picked", which breaks Curated by Nature and The Year, Curated.
  Always run `humanize.py --lexicon <this folder>/jerry-rose.slop.json` (the
  stock list minus `curate`/`curated`). Regenerate it if `slop.json` changes.
- `/ig-viral`, `/ig-comment`, `/ig-dm` and `/ig-story` funnels assume growth
  tactics. Use them only if asked, and filter their output through this file.

## The house

- **Brand:** Jerry Rose. Corporate name: Jerry Rose Inc.
- **People:** Jerry Rose, Founder / Creative Director / President. John
  Simoudis, Managing Director / Deputy Creative Director. Never merge the
  titles or call John the founder.
- **Places:** shop in Maplewood, New Jersey; studio in Summit, New Jersey.
  Design legacy beginning in 1989. Work throughout New Jersey, New York and
  beyond.
- **Positioning:** Jerry Rose offers luxury design and services. Luxury is
  the position, not the vocabulary: show it through specificity, materials,
  judgment and care. Use the word "luxury" rarely in captions and never
  stacked with other superlatives.
- **Established line:** Curated by Nature.
- **Homepage language:** Flowers are our Origin / Design is our Language.
- **House style (working definition):** nature edited with an artist's eye,
  shaped by the season, responsive to its setting, and composed around how
  people live and gather. Restraint is judgment, not minimalism: the work can
  be exuberant, saturated, theatrical and abundant.
- **Not approved, do not use as a tagline:** The Art of the Welcome.
- **Do not publish without rechecking:** prices, contact details,
  availability, titles, service promises.

## Who we are talking to

Private clients, couples, hosts, and relevant corporate and hospitality
clients. Sophisticated and warm. Never use wealth labels (UHNW and similar)
in public copy.

## The two accounts

### @jerryroseevents

- **Territory:** event design and floral work: weddings, celebrations and
  the floral design behind them. The Art of Gathering.
- **Emphasis:** gathering and experience: arrival, transitions, the table
  from the guest's seat, dining, light as evening arrives, departure.
- **Scope guard:** floral and event design does not automatically include
  full wedding planning, catering, transport or every production service.
  Do not imply it does.
- **Link destination:** jerryrose.com (link in bio; never in the caption)

### @jerryrosehomeandgarden

- **Territory:** seasonal plantings, exterior design work, gardens and
  interiors: entrances, steps, terraces, containers, outdoor living and the
  rooms inside. The Year, Curated.
- **Emphasis:** how a house meets the season, outside and in: containers,
  vessels and planting, structure that stays while the season changes, and
  the relationship between the garden and the rooms.
- **Interiors:** seasonal interior work for the home (holiday decor, indoor
  compositions) posts here. An arrangement made for an event stays on
  @jerryroseevents.
- **Scope guard:** seasonal styling is not licensed landscape architecture.
  Do not promise maintenance unless contracted. Horticultural advice depends
  on site conditions (exposure, watering, drainage); ask before giving it.
- **Link destination:** jerryrose.com (link in bio; never in the caption)

### Shared

Both accounts show the same design intelligence. A post on one may echo a
principle from the other; neither becomes a feed of the other.

- **Floral work:** @jerryroseevents. Planted, garden and interior work:
  @jerryrosehomeandgarden. A cut arrangement for an event is floral; a
  planted container or a seasonal interior for a home is home and garden.
  When it is unclear, the user decides; they name the account per photo.
- **Flower orders:** @jerryroseevents.
- **Gifting:** not on Instagram. Do not write gifting posts or gifting asks
  ("send flowers", "the perfect gift") on either account.
- **Corporate work:** @jerryroseevents. Company and brand names, logos,
  venues and event details need the client's authorization, the same as a
  private client. Assume none is given unless the user says so.

## The Jerry Rose Point of View

The ongoing editorial series. Each post picks one pillar, connects one
concrete visual or project detail to one principle, and where helpful one
human consequence.

| Pillar | Subjects |
| --- | --- |
| How We See | Composition, color, proportion, scale, editing, surprise |
| How Nature Leads | Seasonality, botanical character, movement, gardens, materials |
| How People Live | Collections, homes, rituals, traditions, stories, entertaining |
| How Hospitality Feels | Arrival, anticipation, comfort, discretion, generosity, host confidence |

Working design question: "What belongs here?" Use it as a lens, not a
slogan, and never as a claim of ownership.

## What we sound like

- **Register:** a creative director's specificity and a good host's warmth.
  Confident, editorial, observant, intelligent, approachable. Detail
  communicates luxury; adjectives do not.
- **Moves:** active verbs, concrete nouns, short sentences, one idea per
  paragraph. Explain a choice: why this vessel, this color relationship, this
  scale, this placement, this seasonal material.
- **Words that help when they clarify:** proportion, gesture, composition,
  rhythm, texture, sculptural, collected, garden-rooted, seasonal.
- **Do not repeat as branding:** curated, intentional, quiet, belongs. Vary
  them.
- **Never:** exquisite, vintage splendor, layered immersive, grocery store
  flowers, elevate your experience, unforgettable magic, "where X meets Y",
  empty luxury superlatives.
- **Avoid:** repeated "not X, but Y". State the positive idea directly.
- **Never dismiss** other styles, budgets, designers or clients.
- **Emoji:** none by default.

### Calibration lines (from the brand skill; examples, not templates)

- "The vessel sets the proportion. The branches give it movement. Together,
  they establish the room's point of view."
- "We consider a table from the guest's seat: the view across it, the space
  for conversation, the light as evening arrives."
- "Fall planting begins with composition: sculptural foliage, a deeper
  palette, and an entrance ready for the season ahead."
- "A vessel with character. A cutting from the garden. A small composition
  that connects the house to what is growing outside."

- **Three real captions from each account that sound most like us:** TODO
  (paste them; they will calibrate better than the lines above)

## Off limits

- **Discretion:** no client names, addresses, venues, event details or
  identifying images without authorization. Assume none is given unless the
  user says so.
- **We don't post other people's work.** No reposts, regrams, user-generated
  content, or collaborator posts that feature someone else's design. Event
  photos often include other vendors' work (venue, planner, catering, cake,
  lighting, rentals): captions describe only what Jerry Rose designed, and
  never imply "we" made the whole room.
- **Vendor credits.** When a photo includes vendor work, every vendor is
  listed and credited with their Instagram handle, on its own lines after
  the caption and before `Photos: @simoudis`:

  ```
  Venue: @handle
  Planning: @handle
  Lighting: @handle
  Photos: @simoudis
  ```

  Never guess a handle or a vendor's role. If the user has not supplied them,
  leave `{{vendor role}}: {{@handle}}` and flag it. A caption with vendor
  work in frame and missing credits is not ready to post.
- **Collab posts.** Sometimes a post is a collaboration, published to both
  accounts through Instagram's collaborator invite. Only when the user says
  a post is a collab; never suggest one on your own. On a collab:
  - The caption appears on both grids, so write it to stand for both:
    Jerry Rose's part in "we" terms, the collaborator's part named plainly
    and without claiming it.
  - The vendor credit block still applies, including the collaborator.
  - Add `collab: @handle (send the invite in the app)` to the receipt. The
    invite is sent when posting and the collaborator must accept it; a skill
    cannot do either.
  - Featuring the collaborator's work on a collab is allowed. It is the one
    exception to "we don't post other people's work". `/ig-viral` research may study
  others' formats but nothing from it is posted, quoted or reused.
- **Never invent:** testimonials, awards, clients, press, partnerships,
  sustainability credentials, historical claims, service guarantees.
- **No archive claims:** the photo archive has not been visually audited.
- **No current prices** from memory; ask for the approved source.
- **Topics we do not post about:** TODO

## Proof we can use

- Design legacy beginning in 1989.
- Shop in Maplewood, studio in Summit, NJ.
- TODO: projects, press or outcomes cleared for public use.

## Video

Approved 2026-10-19 as a starting mix; revisit with `/ig-audit` once there
is real data.

| | @jerryrosehomeandgarden | @jerryroseevents |
| --- | --- | --- |
| Carousels | ~60%: one project as a sequence, wide to detail to material | ~50%: an event in order, arrival, room, table, detail, evening |
| Single images | ~25%: the strongest single frames | ~20%: one defining detail |
| Reels | ~15%: slow, ambient, no speech; moving through a space, light changing | ~30%: the room before guests arrive, setup as a time-lapse |

- **Reels are made only when motion shows something stills cannot.** Never
  for reach alone.
- **Series idea (Home + Garden):** the same entrance from the same spot each
  season, posted as a four-slide carousel at year's end. Shows The Year,
  Curated instead of saying it.
- **On camera:** nobody. Jerry Rose will not appear on camera. Hands at
  work (arranging, planting, placing) are allowed. Clients and guests never
  appear without written permission. John Simoudis is behind the camera.
- **Speech:** none. Reels carry no voiceover and no one speaking to camera,
  so `/ig-reel` produces on-screen text and a shot list, not a spoken
  script. Keep on-screen text short and in the house voice.
- **Pace:** not applicable (no voiceover). Time on-screen text by reading
  speed instead: about 3 seconds per short line.
- **Other vendors in motion:** a wide Reel of a room shows others' work too;
  the vendor credit block applies to Reels as well as stills.
